import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, hashPassword, comparePasswords } from "./auth";
import { insertShiftSchema, insertUserSchema, insertShiftPreferenceSchema, shiftPreferences, shifts, insertWeekdayConfigSchema, insertUserCommentSchema, insertHolidaySchema } from "../shared/schema";
import { z } from "zod";
import { addMonths } from 'date-fns';
import {format} from 'date-fns';
import { db } from "./db";
import { and, gte, lte, asc, ne, eq } from "drizzle-orm";
import * as XLSX from 'xlsx';

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // Admin middleware
  const requireAdmin = (req: any, res: any, next: any) => {
    if (!req.isAuthenticated() || req.user.role !== 'admin') {
      console.log("Admin access denied:", {
        isAuthenticated: req.isAuthenticated(),
        userRole: req.user?.role,
        userId: req.user?.id
      });
      return res.sendStatus(403);
    }
    next();
  };

  // Authenticatie middleware
  const requireAuth = (req: any, res: any, next: any) => {
    console.log("=== REQUIRE AUTH DEBUG ===");
    console.log("isAuthenticated:", req.isAuthenticated());
    console.log("session:", req.session);
    console.log("user:", req.user);
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    next();
  };

  // Station management routes
  app.get("/api/stations", async (req, res) => {
    try {
      const stations = await storage.getAllStations();
      res.json(stations);
    } catch (error) {
      console.error("Error getting stations:", error);
      res.status(500).json({ message: "Failed to get stations" });
    }
  });

  app.get("/api/stations/:id", async (req, res) => {
    try {
      const stationId = parseInt(req.params.id);
      const station = await storage.getStation(stationId);
      if (!station) {
        return res.status(404).json({ message: "Station not found" });
      }
      res.json(station);
    } catch (error) {
      console.error("Error getting station:", error);
      res.status(500).json({ message: "Failed to get station" });
    }
  });
  
  // Speciale route voor noodgeval login (ALLEEN VOOR ONTWIKKELING)
  app.post("/api/dev-login", async (req, res) => {
    try {
      const { username } = req.body;
      console.log(`Development login request for ${username}`);
      
      // Haal gebruiker op
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(404).json({ message: "Gebruiker niet gevonden" });
      }
      
      // Log gebruiker in
      req.login(user, (err) => {
        if (err) {
          console.error("Login error:", err);
          return res.status(500).json({ message: "Login error" });
        }
        console.log(`Development login successful for ${username}`);
        res.status(200).json(user);
      });
    } catch (error) {
      console.error("Development login error:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  // Get all users (admin only, filtered by station)
  app.get("/api/users", requireAdmin, async (req, res) => {
    try {
      console.log("=== GET /api/users DEBUG ===");
      console.log("Admin user object:", JSON.stringify(req.user, null, 2));
      console.log("Admin stationId:", (req.user as any).stationId);
      
      const allUsers = await storage.getAllUsers();
      console.log("All users from database:", allUsers.length);
      console.log("Users station IDs:", allUsers.map(u => `${u.username}:${u.stationId}`));
      
      // Filter users by the requesting user's station
      const adminStationId = (req.user as any).stationId;
      const users = allUsers.filter(user => user.stationId === adminStationId);
      console.log(`Filtered to ${users.length} users for station ${adminStationId}`);
      console.log("Filtered users:", users.map(u => `${u.username}:${u.stationId}`));
      
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to get users" });
    }
  });

  // Create new user (admin only)
  app.post("/api/users", requireAdmin, async (req, res) => {
    try {
      console.log("=== POST /api/users DEBUG ===");
      console.log("Admin user object:", JSON.stringify(req.user, null, 2));
      console.log("Admin stationId:", (req.user as any).stationId);
      
      const userData = insertUserSchema.parse(req.body);
      console.log("Original userData:", JSON.stringify(userData, null, 2));
      
      // SECURITY: Force new user to be created for the admin's station only
      const adminStationId = (req.user as any).stationId;
      userData.stationId = adminStationId;
      console.log(`Forced stationId to: ${adminStationId}`);
      console.log("Final userData:", JSON.stringify(userData, null, 2));
      
      const user = await storage.createUser(userData);
      console.log("Created user:", JSON.stringify(user, null, 2));
      
      res.status(201).json(user);
    } catch (error) {
      console.error("USER CREATION ERROR:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json(error.errors);
      } else {
        res.status(500).json({ message: "Failed to create user" });
      }
    }
  });

  // Update user (admin only)
  app.patch("/api/users/:id", requireAdmin, async (req, res) => {
    try {
      // SECURITY: Check if user belongs to admin's station
      const targetUser = await storage.getUser(parseInt(req.params.id));
      if (!targetUser || targetUser.stationId !== (req.user as any).stationId) {
        return res.status(404).json({ message: "User not found" });
      }

      const updateSchema = z.object({
        firstName: z.string().min(1).optional(),
        lastName: z.string().min(1).optional(),
        role: z.enum(["admin", "ambulancier"]).optional(),
        hours: z.number().min(0).max(168).optional(),
      });

      const updateData = updateSchema.parse(req.body);
      const user = await storage.updateUser(parseInt(req.params.id), updateData);
      res.json(user);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json(error.errors);
      } else {
        res.status(500).json({ message: "Failed to update user" });
      }
    }
  });

  // Update user password (admin or self)
  app.patch("/api/users/:id/password", requireAuth, async (req, res) => {
    try {
      // Check if user is admin or updating their own password
      if (req.user?.role !== 'admin' && req.user?.id !== parseInt(req.params.id)) {
        return res.sendStatus(403);
      }

      const data = (req.user?.role === 'admin'
        ? z.object({ password: z.string().min(6) })
        : z.object({
          currentPassword: z.string().min(1),
          newPassword: z.string().min(6)
        })
      ).parse(req.body);

      // Als niet admin, verifieer huidig wachtwoord
      if (req.user?.role !== 'admin') {
        const user = await storage.getUser(parseInt(req.params.id));
        const currentPassword = 'currentPassword' in data ? data.currentPassword : '';
        if (!user || !(await comparePasswords(currentPassword, user.password))) {
          return res.status(400).json({ message: "Huidig wachtwoord is incorrect" });
        }
      }

      const user = await storage.updateUserPassword(
        parseInt(req.params.id),
        // Als admin, gebruik direct het nieuwe wachtwoord, anders gebruik newPassword
        'password' in data ? data.password : data.newPassword
      );

      res.json(user);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json(error.errors);
      } else {
        res.status(500).json({ message: "Failed to update password" });
      }
    }
  });

  // Delete user (admin only)
  app.delete("/api/users/:id", requireAdmin, async (req, res) => {
    try {
      // SECURITY: Check if user belongs to admin's station
      const targetUser = await storage.getUser(parseInt(req.params.id));
      if (!targetUser || targetUser.stationId !== (req.user as any).stationId) {
        return res.status(404).json({ message: "User not found" });
      }

      await storage.deleteUser(parseInt(req.params.id));
      res.sendStatus(200);
    } catch (error) {
      res.status(500).json({ message: "Failed to delete user" });
    }
  });

  // Multi-station management routes
  
  // Get accessible stations for current user
  app.get("/api/user/stations", requireAuth, async (req, res) => {
    try {
      const stations = await storage.getUserAccessibleStations(req.user!.id);
      res.json(stations);
    } catch (error) {
      console.error("Error fetching user stations:", error);
      res.status(500).json({ message: "Failed to get accessible stations" });
    }
  });

  // Station switching (server-side, works without JavaScript)
  app.post("/switch-station", requireAuth, async (req: any, res) => {
    try {
      const { stationId } = req.body;
      console.log("🔄 Station switch requested:", { userId: req.user.id, stationId });
      
      // Verify user has access to this station
      const accessibleStations = await storage.getUserAccessibleStations(req.user.id);
      const hasAccess = accessibleStations.some(station => station.id === parseInt(stationId));
      
      if (!hasAccess) {
        console.log("❌ Access denied to station:", stationId);
        return res.status(403).send("No access to this station");
      }
      
      // Update user's current station in session
      req.user.stationId = parseInt(stationId);
      
      // Update session
      req.login(req.user, (err: any) => {
        if (err) {
          console.error("Session update error:", err);
          return res.status(500).send("Failed to switch station");
        }
        
        console.log("✅ Station switched successfully to:", stationId);
        res.redirect("/dashboard");
      });
      
    } catch (error) {
      console.error("Error switching station:", error);
      res.status(500).send("Failed to switch station");
    }
  });

  // Add user to station (admin only)
  app.post("/api/users/:userId/stations/:stationId", requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const stationId = parseInt(req.params.stationId);
      
      // Verify user exists and admin has access to the user's primary station
      const targetUser = await storage.getUser(userId);
      if (!targetUser || targetUser.stationId !== (req.user as any).stationId) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Verify the station exists
      const station = await storage.getStation(stationId);
      if (!station) {
        return res.status(404).json({ message: "Station not found" });
      }
      
      await storage.addUserToStation(userId, stationId);
      res.json({ message: "User toegevoegd aan station" });
    } catch (error) {
      console.error("Error adding user to station:", error);
      res.status(500).json({ message: "Failed to add user to station" });
    }
  });

  // Remove user from station (admin only)
  app.delete("/api/users/:userId/stations/:stationId", requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const stationId = parseInt(req.params.stationId);
      
      // Verify user exists and admin has access to the user's primary station
      const targetUser = await storage.getUser(userId);
      if (!targetUser || targetUser.stationId !== (req.user as any).stationId) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Don't allow removing user from their primary station
      if (targetUser.stationId === stationId) {
        return res.status(400).json({ message: "Cannot remove user from their primary station" });
      }
      
      await storage.removeUserFromStation(userId, stationId);
      res.json({ message: "User verwijderd van station" });
    } catch (error) {
      console.error("Error removing user from station:", error);
      res.status(500).json({ message: "Failed to remove user from station" });
    }
  });

  // Get shift preferences for a month
  app.get("/api/preferences", requireAuth, async (req, res) => {
    try {
      const { month, year } = req.query;
      if (!month || !year) {
        return res.status(400).json({ message: "Month and year are required" });
      }

      const preferences = await storage.getUserShiftPreferences(
        req.user!.id,
        parseInt(month as string),
        parseInt(year as string)
      );
      res.json(preferences);
    } catch (error) {
      res.status(500).json({ message: "Failed to get preferences" });
    }
  });
  
  // Get preferences for a specific user (for admin view)
  app.get("/api/preferences/:userId/:month/:year", requireAdmin, async (req, res) => {
    try {
      const { userId, month, year } = req.params;
      
      // SECURITY: Check if user belongs to admin's station
      const targetUser = await storage.getUser(parseInt(userId));
      if (!targetUser || targetUser.stationId !== (req.user as any).stationId) {
        return res.status(404).json({ message: "User not found" });
      }

      const preferences = await storage.getUserShiftPreferences(
        parseInt(userId),
        parseInt(month),
        parseInt(year)
      );
      res.json(preferences);
    } catch (error) {
      console.error("Error fetching user preferences:", error);
      res.status(500).json({ message: "Failed to get user preferences" });
    }
  });
  
  // Clear all preferences for a user and month
  app.delete("/api/preferences/clearMonth/:userId/:month/:year", requireAdmin, async (req, res) => {
    try {
      const { userId, month, year } = req.params;
      
      // SECURITY: Check if user belongs to admin's station
      const targetUser = await storage.getUser(parseInt(userId));
      if (!targetUser || targetUser.stationId !== (req.user as any).stationId) {
        return res.status(404).json({ message: "User not found" });
      }

      const userPrefs = await storage.getUserShiftPreferences(
        parseInt(userId),
        parseInt(month),
        parseInt(year)
      );
      
      // Delete each preference
      for (const pref of userPrefs) {
        await storage.deleteShiftPreference(pref.id);
      }
      
      res.status(200).json({ message: `Deleted ${userPrefs.length} preferences for user ${userId} in ${month}/${year}` });
    } catch (error) {
      console.error("Error clearing preferences:", error);
      res.status(500).json({ message: "Failed to clear preferences" });
    }
  });
  
  // Track active processes
  let isGeneratingPreferences = false;
  let currentProgress = { percentage: 0, message: "", isActive: false };
  let deleteProgress = { percentage: 0, message: "", isActive: false };
  let generateProgress = { percentage: 0, message: "", isActive: false };

  // Progress endpoints for frontend polling
  app.get("/api/preferences/progress", requireAdmin, (req, res) => {
    res.json(currentProgress);
  });

  app.get("/api/schedule/delete-progress", requireAdmin, (req, res) => {
    res.json(deleteProgress);
  });

  app.get("/api/schedule/generate-progress", (req, res) => {
    res.json(generateProgress);
  });

  // Generate random preferences for testing (admin only)
  app.post("/api/preferences/generate-test-data", requireAdmin, async (req, res) => {
    try {
      // Check if another process is already running
      if (isGeneratingPreferences) {
        return res.status(409).json({ 
          message: "Er is al een voorkeurengeneratie proces bezig. Wacht tot het huidige proces is voltooid." 
        });
      }

      const { month, year, userId } = req.body;
      
      if (!month || !year) {
        return res.status(400).json({ message: "Month and year are required" });
      }

      // Mark process as active
      isGeneratingPreferences = true;
      currentProgress = { percentage: 0, message: "Voorkeurengeneratie gestart...", isActive: true };
      console.log("[BLOKKERING] Voorkeurengeneratie proces gestart - nieuwe verzoeken worden geblokkeerd");
      
      let users;
      if (userId) {
        const user = await storage.getUser(userId);
        if (!user) {
          return res.status(404).json({ message: "User not found" });
        }
        users = [user];
      } else {
        users = await storage.getAllUsers();
        // Include all users including admins
      }
      
      // Eerst alle bestaande voorkeuren voor deze maand/jaar verwijderen
      currentProgress.message = `Verwijderen van bestaande voorkeuren voor maand ${month}/${year}...`;
      console.log(`[0%] Verwijderen van bestaande voorkeuren voor maand ${month}/${year}...`);
      
      for (let userIndex = 0; userIndex < users.length; userIndex++) {
        const user = users[userIndex];
        const deleteProgress = Math.round((userIndex / users.length) * 50); // 0% tot 50%
        
        // Haal bestaande voorkeuren op
        const existingPreferences = await storage.getUserShiftPreferences(user.id, month, year);
        
        // Verwijder elke bestaande voorkeur
        for (const preference of existingPreferences) {
          await storage.deleteShiftPreference(preference.id);
        }
        
        currentProgress.percentage = deleteProgress;
        currentProgress.message = `Verwijderd voor ${user.username} (${userIndex + 1}/${users.length})`;
        console.log(`[${deleteProgress}%] ${existingPreferences.length} voorkeuren verwijderd voor gebruiker ${user.username} (${userIndex + 1}/${users.length})`);
      }
      
      currentProgress.percentage = 50;
      currentProgress.message = "Nieuwe voorkeuren genereren...";
      console.log(`[50%] Alle bestaande voorkeuren verwijderd, nu nieuwe voorkeuren genereren...`);
      
      const daysInMonth = new Date(year, month, 0).getDate();
      let createdPreferences = 0;
      const totalOperations = users.length * daysInMonth;
      let completedOperations = 0;
      
      console.log(`[50%] Begonnen met genereren van voorkeuren voor ${users.length} gebruikers...`);
      
      for (let userIndex = 0; userIndex < users.length; userIndex++) {
        const user = users[userIndex];
        const userProgress = Math.round(50 + ((userIndex / users.length) * 40)); // 50% tot 90%
        currentProgress.percentage = userProgress;
        currentProgress.message = `Voorkeuren genereren voor ${user.username} (${userIndex + 1}/${users.length})`;
        console.log(`[${userProgress}%] Voorkeuren genereren voor ${user.username} (${userIndex + 1}/${users.length})`);
        
        // Voor elke dag in de maand
        for (let day = 1; day <= daysInMonth; day++) {
          const currentDate = new Date(year, month - 1, day);
          const dayOfWeek = currentDate.getDay(); // 0 is zondag, 6 is zaterdag
          const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
          
          // For testing: even userId = more night shifts, odd = more day shifts
          const isEvenUserId = user.id % 2 === 0;
          
          // Bepaal beschikbaarheid - 25% kans op beschikbaarheid
          const randomValue = Math.random();
          
          // Voor elke gebruiker maken we een vaste verdeling van beschikbare dagen
          // Elke gebruiker krijgt precies 25% beschikbaarheid (8 dagen voor een maand van 31 dagen)
          
          // Gebruik een deterministische aanpak op basis van userID en dag van de maand
          // Dit zorgt ervoor dat elke gebruiker andere dagen beschikbaar is
          const userOffset = user.id % 4; // Verdeel gebruikers in 4 groepen
          
          // Bepaal of de dag beschikbaar is voor deze gebruiker
          // We delen de maand in 4 groepen van ~8 dagen, en elke userOffset groep krijgt andere dagen
          const isAvailable = ((day + userOffset) % 4 === 0);
          
          if (isAvailable) {
            // Even user IDs prefer night shifts
            const preferNight = isEvenUserId ? Math.random() < 0.7 : Math.random() < 0.3;
            const shiftType = preferNight ? "night" : "day";
            
            // Preference types: 75% full shifts, 25% half shifts (verdeeld over first en second)
            let preferenceType;
            const halfShiftRand = Math.random();
            // Exacte verdeling: 75% volledig, 25% half (12.5% eerste helft, 12.5% tweede helft)
            if (halfShiftRand < 0.75) {
              preferenceType = "full";
            } else if (halfShiftRand < 0.875) {
              preferenceType = "first";
            } else {
              preferenceType = "second";
            }
            
            // Bepaal start- en eindtijden op basis van type shift en voorkeurstype
            const startTime = new Date(currentDate);
            const endTime = new Date(currentDate);
            
            if (shiftType === "day") {
              if (preferenceType === "full") {
                startTime.setHours(7, 0, 0, 0);
                endTime.setHours(19, 0, 0, 0);
              } else if (preferenceType === "first") {
                startTime.setHours(7, 0, 0, 0);
                endTime.setHours(13, 0, 0, 0);
              } else { // second
                startTime.setHours(13, 0, 0, 0);
                endTime.setHours(19, 0, 0, 0);
              }
            } else { // night
              if (preferenceType === "full") {
                startTime.setHours(19, 0, 0, 0);
                // Voor nachtshifts: eindtijd op de volgende dag
                endTime.setDate(endTime.getDate() + 1);
                endTime.setHours(7, 0, 0, 0);
              } else if (preferenceType === "first") {
                startTime.setHours(19, 0, 0, 0);
                endTime.setHours(23, 0, 0, 0);
              } else { // second
                startTime.setHours(23, 0, 0, 0);
                // Voor tweede helft: eindtijd op de volgende dag
                endTime.setDate(endTime.getDate() + 1);
                endTime.setHours(7, 0, 0, 0);
              }
            }
            
            // Creëer de beschikbaarheidsvoorkeur
            await storage.createShiftPreference({
              userId: user.id,
              stationId: user.stationId,
              date: currentDate,
              type: shiftType,
              startTime: startTime,
              endTime: endTime,
              month,
              year,
              canSplit: preferenceType === "full" && Math.random() < 0.2, // 20% kans dat volledige shift gesplitst mag worden
              notes: `Automatisch gegenereerd voor test (${preferenceType} ${shiftType} shift)`
            });
            createdPreferences++;
          } 
          // Voor alle andere dagen (75%) expliciet markeren als onbeschikbaar
          else {
            // Maak een "unavailable" voorkeur
            await storage.createShiftPreference({
              userId: user.id,
              stationId: user.stationId,
              date: currentDate,
              type: "unavailable",
              startTime: null,
              endTime: null,
              month,
              year,
              canSplit: false,
              notes: "Automatisch gegenereerd voor test (niet beschikbaar)"
            });
            createdPreferences++;
          }
          
          completedOperations++;
          // GEEN neutrale voorkeuren meer
        }
        
        // Log voortgang na elke gebruiker
        const overallProgress = Math.round(90 + ((completedOperations / totalOperations) * 10)); // 90% tot 100%
        currentProgress.percentage = overallProgress;
        currentProgress.message = `Voltooid voor ${user.username} - ${completedOperations}/${totalOperations} operaties`;
        console.log(`[${overallProgress}%] Voltooid voor ${user.username} - ${completedOperations}/${totalOperations} operaties`);
      }
      
      currentProgress.percentage = 100;
      currentProgress.message = "Voorkeuren generatie voltooid!";
      console.log(`[100%] Voorkeuren generatie voltooid!`);
      
      // Sla de huidige tijd op als tijdstempel per maand voor de laatste generatie
      const now = new Date();
      const timestamp = now.toISOString();
      const key = `last_preferences_generated_${month}_${year}`;
      await storage.setSystemSetting(key, timestamp);
      
      // Release the lock and reset progress
      isGeneratingPreferences = false;
      currentProgress = { percentage: 0, message: "", isActive: false };
      console.log("[BLOKKERING] Voorkeurengeneratie proces voltooid - nieuwe verzoeken zijn weer toegestaan");
      
      res.status(200).json({ 
        message: `Successfully generated ${createdPreferences} test preferences for ${users.length} users`,
        timestamp: timestamp,
        formattedTimestamp: now.toLocaleString('nl-NL', { 
          timeZone: 'Europe/Brussels',
          day: '2-digit',
          month: '2-digit',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: false 
        })
      });
    } catch (error) {
      console.error("Error generating test preferences:", error);
      
      // Release the lock in case of error
      isGeneratingPreferences = false;
      currentProgress = { percentage: 0, message: "", isActive: false };
      console.log("[BLOKKERING] Voorkeurengeneratie proces gefaald - blokkering vrijgegeven");
      
      res.status(500).json({ 
        message: "Failed to generate test preferences",
        error: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });
  
  // Get all preferences for admin view
  app.get("/api/preferences/all", requireAdmin, async (req, res) => {
    try {
      // Get month and year from query parameters, fallback to current date
      const { month, year } = req.query;
      const targetMonth = month ? parseInt(month as string) : new Date().getMonth() + 1;
      const targetYear = year ? parseInt(year as string) : new Date().getFullYear();
      
      // Get all shift preferences for the specified month/year using SQL query
      const startDate = new Date(targetYear, targetMonth - 1, 1);
      const endDate = new Date(targetYear, targetMonth, 0);
      
      const allPreferences = await db.select()
        .from(shiftPreferences)
        .where(
          and(
            gte(shiftPreferences.date, startDate),
            lte(shiftPreferences.date, endDate)
          )
        )
        .orderBy(asc(shiftPreferences.date), asc(shiftPreferences.userId));
      
      res.json(allPreferences);
    } catch (error) {
      console.error("Error fetching preferences:", error);
      res.status(500).json({ message: "Failed to get preferences" });
    }
  });

  // Route handler for creating preferences
  app.post("/api/preferences", requireAuth, async (req, res) => {
    try {
      console.log('Received preference data:', req.body);

      const preferenceData = {
        ...req.body,
        userId: req.user!.id,
        stationId: req.user!.stationId, // BUGFIX: Add missing stationId
        date: new Date(req.body.date),
        startTime: req.body.startTime ? new Date(req.body.startTime) : null,
        endTime: req.body.endTime ? new Date(req.body.endTime) : null,
        status: "pending"
      };

      console.log('Processing preference with data:', preferenceData);

      // Check if there's already a preference for this date
      const existingPreferences = await storage.getUserShiftPreferences(
        req.user!.id,
        preferenceData.month,
        preferenceData.year
      );

      const existingPreference = existingPreferences.find(pref => 
        format(new Date(pref.date), "yyyy-MM-dd") === format(new Date(preferenceData.date), "yyyy-MM-dd")
      );

      let preference;
      if (existingPreference) {
        // Update existing preference
        preference = await storage.updateShiftPreference(existingPreference.id, preferenceData);
        console.log('Updated existing preference:', preference);
      } else {
        // Create new preference
        preference = await storage.createShiftPreference(preferenceData);
        console.log('Created new preference:', preference);
      }

      res.status(201).json(preference);
    } catch (error) {
      console.error('Error processing preference:', error);
      res.status(500).json({
        message: "Er is een fout opgetreden bij het opslaan van de voorkeur"
      });
    }
  });

  // Delete shift preference
  app.delete("/api/preferences/:id", requireAuth, async (req, res) => {
    try {
      // Check if preference exists and belongs to user
      const preference = await storage.getShiftPreference(parseInt(req.params.id));
      if (!preference) {
        return res.status(404).json({ message: "Voorkeur niet gevonden" });
      }

      if (preference.userId !== req.user!.id) {
        return res.status(403).json({ message: "U heeft geen toegang tot deze voorkeur" });
      }

      await storage.deleteShiftPreference(parseInt(req.params.id));
      res.sendStatus(200);
    } catch (error) {
      res.status(500).json({ message: "Kon voorkeur niet verwijderen" });
    }
  });


  // Get all shifts - optionally filter by month/year
  app.get("/api/shifts", requireAuth, async (req, res) => {
    try {
      let shifts;
      const userStationId = req.user?.stationId;
      
      if (req.query.month && req.query.year) {
        const month = parseInt(req.query.month as string);
        const year = parseInt(req.query.year as string);
        shifts = await storage.getShiftsByMonth(month, year, userStationId);
      } else {
        shifts = await storage.getAllShifts(userStationId);
      }
      
      res.status(200).json(shifts);
    } catch (error) {
      console.error("Error getting shifts:", error);
      res.status(500).json({ message: "Failed to get shifts" });
    }
  });

  // Create a new shift
  app.post("/api/shifts", requireAdmin, async (req, res) => {
    try {
      console.log('Creating shift with data:', req.body);
      
      const shiftData = {
        ...req.body,
        userId: req.body.userId || 0, // Default to unassigned
        stationId: req.body.stationId || req.user?.stationId,
        date: new Date(req.body.date),
        startTime: new Date(req.body.startTime),
        endTime: new Date(req.body.endTime),
        month: new Date(req.body.date).getMonth() + 1,
        year: new Date(req.body.date).getFullYear()
      };
      
      const shift = await storage.createShift(shiftData);
      console.log('Shift created successfully:', shift);
      
      res.status(201).json(shift);
    } catch (error) {
      console.error("Error creating shift:", error);
      res.status(500).json({ message: "Failed to create shift" });
    }
  });
  
  // Delete all shifts for a specific month/year
  app.delete("/api/shifts/month", requireAdmin, async (req, res) => {
    try {
      const { month, year } = req.body;
      if (!month || !year) {
        return res.status(400).json({ message: "Month and year are required" });
      }
      
      const userStationId = req.user?.stationId;
      console.log(`Deleting all shifts for ${month}/${year} for station ${userStationId}`);
      
      // Haal eerst alle shifts op voor deze maand/jaar en station
      const shifts = await storage.getShiftsByMonth(parseInt(month), parseInt(year), userStationId);
      const totalShifts = shifts.length;
      
      console.log(`[0%] Begonnen met verwijderen van ${totalShifts} shifts...`);
      
      // Initialize progress tracking
      deleteProgress = { percentage: 0, message: "Beginnen met verwijderen...", isActive: true };
      
      // Verwijder alle shifts voor deze maand/jaar met voortgangsindicatie
      for (let i = 0; i < shifts.length; i++) {
        await storage.deleteShift(shifts[i].id);
        
        // Update progress for every shift
        const progress = Math.round(((i + 1) / totalShifts) * 100);
        deleteProgress.percentage = progress;
        deleteProgress.message = `${i + 1}/${totalShifts} shifts verwijderd`;
        
        // Log voortgang elke 10 shifts of bij de laatste
        if (i % 10 === 0 || i === shifts.length - 1) {
          console.log(`[${progress}%] ${i + 1}/${totalShifts} shifts verwijderd`);
        }
      }
      
      // Complete progress tracking
      deleteProgress = { percentage: 100, message: "Verwijderen voltooid!", isActive: false };
      
      console.log(`[100%] ${totalShifts} shifts succesvol verwijderd voor ${month}/${year}`);
      res.status(200).json({ 
        message: `${totalShifts} shifts verwijderd voor ${month}/${year}`,
        count: totalShifts
      });
    } catch (error) {
      console.error("Error deleting shifts:", error);
      res.status(500).json({ message: "Failed to delete shifts" });
    }
  });

  // Get shifts by month
  app.get("/api/shifts/month/:month/:year", requireAuth, async (req, res) => {
    try {
      const { month, year } = req.params;
      const userStationId = req.user?.stationId;
      const shifts = await storage.getShiftsByMonth(
        parseInt(month),
        parseInt(year),
        userStationId
      );
      res.json(shifts);
    } catch (error) {
      res.status(500).json({ message: "Failed to get shifts" });
    }
  });

  // Generate monthly schedule (admin only)
  app.post("/api/shifts/generate/:month/:year", requireAdmin, async (req, res) => {
    try {
      const { month, year } = req.params;
      const userStationId = req.user?.stationId;
      const generatedShifts = await storage.generateMonthlySchedule(
        parseInt(month),
        parseInt(year),
        userStationId
      );
      res.status(200).json(generatedShifts);
    } catch (error) {
      console.error("Error generating schedule:", error);
      res.status(500).json({ message: "Failed to generate schedule" });
    }
  });
  
  // New API endpoint for schedule generation
  // TIJDELIJKE AANPASSING: veranderd van requireAdmin naar publiek toegankelijk
  // zodat we de functionaliteit kunnen demonstreren
  app.post("/api/schedule/generate", requireAuth, async (req, res) => {
    try {
      const { month, year } = req.body;
      const userStationId = req.user?.stationId;
      
      
      // Controleer of gebruiker ingelogd is en stationId heeft
      if (!req.user || !userStationId) {
        console.error("Geen geldige gebruiker of stationId:", { 
          user: req.user?.username, 
          stationId: userStationId,
          fullUser: req.user 
        });
        return res.status(401).json({ message: "Geen geldige sessie of station informatie. Log opnieuw in." });
      }
      
      console.log(`[0%] Planning generatie gestart voor ${month}/${year} voor station ${userStationId}`);
      
      // Initialize progress tracking
      generateProgress = { percentage: 0, message: "Planning generatie gestart...", isActive: true };
      
      // Pass progress callback to storage function
      const progressCallback = (percentage: number, message: string) => {
        generateProgress = { percentage, message, isActive: true };
        console.log(`[${percentage}%] ${message}`);
      };
      
      const generatedShifts = await storage.generateMonthlySchedule(month, year, userStationId, progressCallback);
      
      
      // Complete progress tracking
      generateProgress = { percentage: 100, message: "Planning voltooid!", isActive: false };
      console.log(`[100%] Planning generatie voltooid voor ${month}/${year}`);
      
      // Sla de huidige tijd op als tijdstempel per maand voor de laatste planning generatie
      const now = new Date();
      const timestamp = now.toISOString();
      const key = `last_schedule_generated_${month}_${year}`;
      await storage.setSystemSetting(key, timestamp);
      
      
      res.status(200).json(generatedShifts);
    } catch (error) {
      console.error("Error generating schedule:", error);
      res.status(500).json({ message: "Failed to generate schedule", error: String(error) });
    }
  });
  
  
  // Get a specific shift by id
  app.get("/api/shifts/:id", requireAuth, async (req, res) => {
    try {
      const shift = await storage.getShift(parseInt(req.params.id));
      if (!shift) {
        return res.status(404).json({ message: "Shift not found" });
      }
      res.status(200).json(shift);
    } catch (error) {
      console.error("Error getting shift:", error);
      res.status(500).json({ message: "Failed to get shift" });
    }
  });
  
  // Update a shift (for manual planning adjustments)
  app.patch("/api/shifts/:id", requireAdmin, async (req, res) => {
    try {
      const shiftId = parseInt(req.params.id);
      const updateData = req.body;
      
      // Validate the shift exists
      const existingShift = await storage.getShift(shiftId);
      if (!existingShift) {
        return res.status(404).json({ message: "Shift not found" });
      }
      
      // Update the shift
      const updatedShift = await storage.updateShift(shiftId, updateData);
      res.status(200).json(updatedShift);
    } catch (error) {
      console.error("Error updating shift:", error);
      res.status(500).json({ message: "Failed to update shift" });
    }
  });

  // Split a night shift into two half shifts
  app.post("/api/shifts/:id/split", requireAdmin, async (req, res) => {
    try {
      const shiftId = parseInt(req.params.id);
      
      // Get the existing shift
      const existingShift = await storage.getShift(shiftId);
      if (!existingShift) {
        return res.status(404).json({ message: "Shift not found" });
      }
      
      // Only day and night shifts can be split
      if (existingShift.type !== "night" && existingShift.type !== "day") {
        return res.status(400).json({ message: "Only day and night shifts can be split" });
      }
      
      // Check if already split
      if (existingShift.isSplitShift) {
        return res.status(400).json({ message: "Shift is already split" });
      }
      
      // Determine split times based on shift type
      let firstHalfStart, firstHalfEnd, secondHalfStart, secondHalfEnd;
      
      if (existingShift.type === "night") {
        // Night shift: 19:00-23:00 and 23:00-07:00
        firstHalfStart = new Date(existingShift.date.getFullYear(), existingShift.date.getMonth(), existingShift.date.getDate(), 19, 0, 0);
        firstHalfEnd = new Date(existingShift.date.getFullYear(), existingShift.date.getMonth(), existingShift.date.getDate(), 23, 0, 0);
        secondHalfStart = new Date(existingShift.date.getFullYear(), existingShift.date.getMonth(), existingShift.date.getDate(), 23, 0, 0);
        secondHalfEnd = new Date(existingShift.date.getFullYear(), existingShift.date.getMonth(), existingShift.date.getDate() + 1, 7, 0, 0);
      } else {
        // Day shift: 07:00-13:00 and 13:00-19:00
        firstHalfStart = new Date(existingShift.date.getFullYear(), existingShift.date.getMonth(), existingShift.date.getDate(), 7, 0, 0);
        firstHalfEnd = new Date(existingShift.date.getFullYear(), existingShift.date.getMonth(), existingShift.date.getDate(), 13, 0, 0);
        secondHalfStart = new Date(existingShift.date.getFullYear(), existingShift.date.getMonth(), existingShift.date.getDate(), 13, 0, 0);
        secondHalfEnd = new Date(existingShift.date.getFullYear(), existingShift.date.getMonth(), existingShift.date.getDate(), 19, 0, 0);
      }

      // Update the existing shift to mark it as split and set hours to first half
      await storage.updateShift(shiftId, {
        isSplitShift: true,
        startTime: firstHalfStart,
        endTime: firstHalfEnd,
        userId: 0,
        status: "open",
        splitGroup: shiftId
      });
      
      // Create a second half shift
      const secondHalfShift = await storage.createShift({
        date: existingShift.date,
        type: existingShift.type,
        startTime: secondHalfStart,
        endTime: secondHalfEnd,
        userId: 0,
        status: "open",
        isSplitShift: true,
        splitGroup: shiftId,
        stationId: existingShift.stationId,
        month: existingShift.month,
        year: existingShift.year
      });
      
      res.status(200).json({ 
        message: "Shift successfully split into two half shifts",
        originalShift: shiftId,
        secondHalfShift: secondHalfShift.id
      });
    } catch (error) {
      console.error("Error splitting shift:", error);
      res.status(500).json({ message: "Failed to split shift" });
    }
  });

  // Merge split shifts back into one full night shift
  app.post("/api/shifts/:id/merge", requireAdmin, async (req, res) => {
    try {
      const shiftId = parseInt(req.params.id);
      
      // Get the existing shift
      const existingShift = await storage.getShift(shiftId);
      if (!existingShift) {
        return res.status(404).json({ message: "Shift not found" });
      }
      
      // Only split shifts can be merged
      if (!existingShift.isSplitShift) {
        return res.status(400).json({ message: "Only split shifts can be merged" });
      }
      
      // Find the other half of the split shift
      const allShifts = await storage.getShiftsByMonth(
        existingShift.date.getMonth() + 1,
        existingShift.date.getFullYear()
      );
      
      const splitGroup = existingShift.splitGroup;
      const otherHalf = allShifts.find(shift => 
        shift.id !== shiftId && 
        shift.splitGroup === splitGroup &&
        shift.isSplitShift
      );
      
      if (otherHalf) {
        // Delete the other half
        await storage.deleteShift(otherHalf.id);
      }
      
      // Determine full shift times based on shift type
      let fullShiftStart, fullShiftEnd, shiftDescription;
      
      if (existingShift.type === "night") {
        // Night shift: 19:00-07:00
        fullShiftStart = new Date(existingShift.date.getFullYear(), existingShift.date.getMonth(), existingShift.date.getDate(), 19, 0, 0);
        fullShiftEnd = new Date(existingShift.date.getFullYear(), existingShift.date.getMonth(), existingShift.date.getDate() + 1, 7, 0, 0);
        shiftDescription = "full night shift";
      } else {
        // Day shift: 07:00-19:00
        fullShiftStart = new Date(existingShift.date.getFullYear(), existingShift.date.getMonth(), existingShift.date.getDate(), 7, 0, 0);
        fullShiftEnd = new Date(existingShift.date.getFullYear(), existingShift.date.getMonth(), existingShift.date.getDate(), 19, 0, 0);
        shiftDescription = "full day shift";
      }

      // Update the original shift to be a full shift again
      await storage.updateShift(shiftId, {
        isSplitShift: false,
        splitGroup: null,
        startTime: fullShiftStart,
        endTime: fullShiftEnd,
        userId: 0,
        status: "open"
      });
      
      res.status(200).json({ 
        message: `Split shifts successfully merged into one ${shiftDescription}`,
        mergedShift: shiftId
      });
    } catch (error) {
      console.error("Error merging shifts:", error);
      res.status(500).json({ message: "Failed to merge shifts" });
    }
  });

  // Note: De bulk-import endpoint voor ambulanciers is verwijderd omdat deze niet meer nodig is
  // De ambulanciers zijn al direct toegevoegd via SQL

  // Haal de laatste tijdstempel op voor het genereren van testvoorkeuren (per maand)
  app.get("/api/system/settings/last-preferences-generated", requireAuth, async (req, res) => {
    try {
      const { month, year } = req.query;
      const targetMonth = month ? parseInt(month as string) : new Date().getMonth() + 1;
      const targetYear = year ? parseInt(year as string) : new Date().getFullYear();
      
      const key = `last_preferences_generated_${targetMonth}_${targetYear}`;
      const timestamp = await storage.getSystemSetting(key);
      
      if (timestamp) {
        // Correcte timezone-aware formattering met expliciete opties
        const date = new Date(timestamp);
        res.json({
          timestamp,
          formattedTimestamp: date.toLocaleString('nl-NL', { 
            timeZone: 'Europe/Brussels',
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false 
          })
        });
      } else {
        res.json({
          timestamp: null,
          formattedTimestamp: "Nog niet gegenereerd"
        });
      }
    } catch (error) {
      console.error("Error fetching last preferences generation timestamp:", error);
      res.status(500).json({ message: "Kon tijdstempel niet ophalen" });
    }
  });

  // Haal de laatste tijdstempel op voor het genereren van planning (per maand)
  app.get("/api/system/settings/last-schedule-generated", requireAuth, async (req, res) => {
    try {
      const { month, year } = req.query;
      const targetMonth = month ? parseInt(month as string) : new Date().getMonth() + 1;
      const targetYear = year ? parseInt(year as string) : new Date().getFullYear();
      
      const key = `last_schedule_generated_${targetMonth}_${targetYear}`;
      const timestamp = await storage.getSystemSetting(key);
      
      if (timestamp) {
        // Correcte timezone-aware formattering met expliciete opties
        const date = new Date(timestamp);
        res.json({
          timestamp,
          formattedTimestamp: date.toLocaleString('nl-NL', { 
            timeZone: 'Europe/Brussels',
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false 
          })
        });
      } else {
        res.json({
          timestamp: null,
          formattedTimestamp: "Nog niet gegenereerd"
        });
      }
    } catch (error) {
      console.error("Error fetching last schedule generation timestamp:", error);
      res.status(500).json({ message: "Kon tijdstempel niet ophalen" });
    }
  });

  // Get admin contact information (accessible to all authenticated users)
  app.get("/api/admins/contact", requireAuth, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      const userStationId = req.user?.stationId;
      
      // Filter administrators by the same station as the requesting user
      const admins = users.filter(user => 
        user.role === 'admin' && user.stationId === userStationId
      );
      
      // Return only the contact information, not sensitive data
      const adminContacts = admins.map(admin => ({
        id: admin.id,
        username: admin.username,
        firstName: admin.firstName,
        lastName: admin.lastName,
        role: admin.role,
        stationId: admin.stationId
      }));
      
      res.json(adminContacts);
    } catch (error) {
      console.error("Error fetching admin contacts:", error);
      res.status(500).json({ message: "Kon administrator contactgegevens niet ophalen" });
    }
  });

  // Weekday configuration routes
  app.get("/api/weekday-configs", requireAdmin, async (req, res) => {
    try {
      const userStationId = (req.user as any).stationId;
      const configs = await storage.getWeekdayConfigs(userStationId);
      res.json(configs);
    } catch (error) {
      console.error("Error getting weekday configs:", error);
      res.status(500).json({ message: "Failed to get weekday configurations" });
    }
  });

  app.get("/api/weekday-configs/:dayOfWeek", requireAdmin, async (req, res) => {
    try {
      const dayOfWeek = parseInt(req.params.dayOfWeek);
      const userStationId = (req.user as any).stationId;
      const config = await storage.getWeekdayConfig(dayOfWeek, userStationId);
      if (!config) {
        return res.status(404).json({ message: "Configuration not found" });
      }
      res.json(config);
    } catch (error) {
      console.error("Error getting weekday config:", error);
      res.status(500).json({ message: "Failed to get weekday configuration" });
    }
  });

  app.put("/api/weekday-configs/:dayOfWeek", requireAdmin, async (req, res) => {
    try {
      const dayOfWeek = parseInt(req.params.dayOfWeek);
      const userStationId = (req.user as any).stationId;
      const updateData = req.body;
      
      const updatedConfig = await storage.updateWeekdayConfig(dayOfWeek, updateData, userStationId);
      res.json(updatedConfig);
    } catch (error) {
      console.error("Error updating weekday config:", error);
      res.status(500).json({ message: "Failed to update weekday configuration" });
    }
  });

  app.post("/api/weekday-configs/initialize", requireAdmin, async (req, res) => {
    try {
      const userStationId = (req.user as any).stationId;
      await storage.initializeDefaultWeekdayConfigs(userStationId);
      const configs = await storage.getWeekdayConfigs(userStationId);
      res.json(configs);
    } catch (error) {
      console.error("Error initializing weekday configs:", error);
      res.status(500).json({ message: "Failed to initialize weekday configurations" });
    }
  });

  // Statistics routes
  app.get("/api/statistics/shifts", requireAdmin, async (req, res) => {
    try {
      const { type, year, month, quarter } = req.query;
      
      if (!type || !year) {
        return res.status(400).json({ message: "Type and year are required" });
      }
      
      const targetYear = parseInt(year as string);
      let startDate: Date, endDate: Date;
      
      switch (type) {
        case "month":
          if (!month) {
            return res.status(400).json({ message: "Month is required for monthly statistics" });
          }
          const targetMonth = parseInt(month as string);
          startDate = new Date(targetYear, targetMonth - 1, 1);
          endDate = new Date(targetYear, targetMonth, 0);
          break;
          
        case "quarter":
          if (!quarter) {
            return res.status(400).json({ message: "Quarter is required for quarterly statistics" });
          }
          const targetQuarter = parseInt(quarter as string);
          const quarterStartMonth = (targetQuarter - 1) * 3;
          startDate = new Date(targetYear, quarterStartMonth, 1);
          endDate = new Date(targetYear, quarterStartMonth + 3, 0);
          break;
          
        case "year":
          startDate = new Date(targetYear, 0, 1);
          endDate = new Date(targetYear, 11, 31);
          break;
          
        default:
          return res.status(400).json({ message: "Invalid type. Must be month, quarter, or year" });
      }
      
      // Get users filtered by station
      const allUsers = await storage.getAllUsers();
      const users = allUsers.filter(user => user.stationId === (req.user as any).stationId);
      
      // Get shift preferences for the period (filtered by station)
      const preferences = await db.select()
        .from(shiftPreferences)
        .where(
          and(
            gte(shiftPreferences.date, startDate),
            lte(shiftPreferences.date, endDate),
            eq(shiftPreferences.stationId, (req.user as any).stationId)
          )
        );
      
      // Get actual shifts for the period (filtered by station)
      const actualShifts = await db.select()
        .from(shifts)
        .where(
          and(
            gte(shifts.date, startDate),
            lte(shifts.date, endDate),
            ne(shifts.userId, 0), // Exclude open shifts
            eq(shifts.stationId, (req.user as any).stationId)
          )
        );
      
      // Calculate statistics for each user
      const statistics = users.map(user => {
        const userPreferences = preferences.filter(p => p.userId === user.id);
        const userActualShifts = actualShifts.filter(s => s.userId === user.id);
        
        // Calculate preference hours by type and weekend/weekday
        const prefStats = userPreferences.reduce((acc, pref) => {
          const isWeekend = pref.date.getDay() === 0 || pref.date.getDay() === 6;
          const key = `${pref.type}${isWeekend ? 'Weekend' : 'Week'}` as keyof typeof acc;
          // Only count approved or pending preferences (not unavailable)
          if (pref.type !== 'unavailable') {
            // Standard hours: day = 12h, night = 12h
            const hours = pref.type === 'day' ? 12 : 12;
            acc[key] += hours;
          }
          return acc;
        }, {
          dayWeek: 0,
          nightWeek: 0,
          dayWeekend: 0,
          nightWeekend: 0
        });
        
        // Calculate actual shift hours by type and weekend/weekday
        const actualStats = userActualShifts.reduce((acc, shift) => {
          const isWeekend = shift.date.getDay() === 0 || shift.date.getDay() === 6;
          const key = `${shift.type}${isWeekend ? 'Weekend' : 'Week'}` as keyof typeof acc;
          
          // Calculate actual hours from start/end times
          let hours = 0;
          if (shift.startTime && shift.endTime) {
            const startTime = new Date(shift.startTime);
            const endTime = new Date(shift.endTime);
            hours = Math.abs(endTime.getTime() - startTime.getTime()) / (1000 * 60 * 60);
          } else {
            // Fallback to standard hours if times not available
            hours = shift.type === 'day' ? 12 : 12;
          }
          
          acc[key] += Math.round(hours);
          return acc;
        }, {
          dayWeek: 0,
          nightWeek: 0,
          dayWeekend: 0,
          nightWeekend: 0
        });
        
        // Calculate max hours based on period type
        let periodMultiplier = 1;
        switch (type) {
          case "month":
            periodMultiplier = 1;
            break;
          case "quarter":
            periodMultiplier = 3;
            break;
          case "year":
            periodMultiplier = 12;
            break;
        }
        
        return {
          userId: user.id,
          username: user.username,
          firstName: user.firstName,
          lastName: user.lastName,
          // Preferences (in hours)
          dayShiftWeekHours: prefStats.dayWeek,
          nightShiftWeekHours: prefStats.nightWeek,
          dayShiftWeekendHours: prefStats.dayWeekend,
          nightShiftWeekendHours: prefStats.nightWeekend,
          totalPreferenceHours: prefStats.dayWeek + prefStats.nightWeek + prefStats.dayWeekend + prefStats.nightWeekend,
          // Actual shifts (in hours)
          actualDayShiftWeekHours: actualStats.dayWeek,
          actualNightShiftWeekHours: actualStats.nightWeek,
          actualDayShiftWeekendHours: actualStats.dayWeekend,
          actualNightShiftWeekendHours: actualStats.nightWeekend,
          totalActualHours: actualStats.dayWeek + actualStats.nightWeek + actualStats.dayWeekend + actualStats.nightWeekend,
          // Maximum hours willing to work (adjusted for period)
          maxHours: (user.hours || 0) * periodMultiplier
        };
      });
      
      res.json(statistics);
    } catch (error) {
      console.error("Error fetching shift statistics:", error);
      res.status(500).json({ message: "Failed to get shift statistics" });
    }
  });

  // Export planning to XLSX
  app.get("/api/schedule/export-xlsx", requireAdmin, async (req, res) => {
    try {
      const { month, year } = req.query;
      
      if (!month || !year) {
        return res.status(400).json({ message: "Month and year are required" });
      }
      
      const targetMonth = parseInt(month as string);
      const targetYear = parseInt(year as string);
      
      // Get shifts for the month
      const shifts = await storage.getShiftsByMonth(targetMonth, targetYear);
      
      // Get all users to map names
      const users = await storage.getAllUsers();
      const userMap = new Map(users.map(u => [u.id, u]));
      
      // Sort shifts by date
      const sortedShifts = shifts.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
      
      // Prepare data for Excel
      const excelData = [
        // Header row
        ['Datum', 'Dag', 'Type', 'Start Tijd', 'Eind Tijd', 'Voornaam', 'Achternaam', 'Status']
      ];
      
      // Add data rows
      for (const shift of sortedShifts) {
        const user = userMap.get(shift.userId);
        const date = new Date(shift.date);
        const dayName = date.toLocaleDateString('nl-NL', { weekday: 'long' });
        const dateStr = date.toLocaleDateString('nl-NL');
        const startTime = new Date(shift.startTime).toLocaleTimeString('nl-NL', { hour: '2-digit', minute: '2-digit' });
        const endTime = new Date(shift.endTime).toLocaleTimeString('nl-NL', { hour: '2-digit', minute: '2-digit' });
        
        const firstName = user ? user.firstName : 'Open';
        const lastName = user ? user.lastName : 'Shift';
        const type = shift.type === 'day' ? 'Dag' : 'Nacht';
        const status = shift.status === 'planned' ? 'Gepland' : 'Open';
        
        excelData.push([
          dateStr,
          dayName,
          type,
          startTime,
          endTime,
          firstName,
          lastName,
          status
        ]);
      }
      
      // Create workbook and worksheet
      const workbook = XLSX.utils.book_new();
      const worksheet = XLSX.utils.aoa_to_sheet(excelData);
      
      // Set column widths
      const colWidths = [
        { wch: 12 }, // Datum
        { wch: 12 }, // Dag
        { wch: 8 },  // Type
        { wch: 12 }, // Start Tijd
        { wch: 12 }, // Eind Tijd
        { wch: 15 }, // Voornaam
        { wch: 15 }, // Achternaam
        { wch: 10 }  // Status
      ];
      worksheet['!cols'] = colWidths;
      
      // Add worksheet to workbook
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Planning');
      
      // Generate XLSX buffer
      const xlsxBuffer = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
      
      // Set headers for XLSX download
      const filename = `planning_${targetMonth}_${targetYear}.xlsx`;
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.setHeader('Content-Length', xlsxBuffer.length);
      
      res.end(xlsxBuffer);
      
    } catch (error) {
      console.error("Error exporting XLSX schedule:", error);
      res.status(500).json({ message: "Failed to export XLSX schedule" });
    }
  });

  // Gebruiker opmerkingen routes
  
  // Get user comment for specific month/year
  app.get("/api/comments/:month/:year", requireAuth, async (req, res) => {
    try {
      const { month, year } = req.params;
      const userId = req.user?.id;
      if (!userId) return res.sendStatus(401);
      
      const comment = await storage.getUserComment(
        userId,
        parseInt(month),
        parseInt(year),
        req.user?.stationId
      );
      
      res.json(comment);
    } catch (error) {
      console.error("Error getting user comment:", error);
      res.status(500).json({ message: "Failed to get comment" });
    }
  });

  // Create or update user comment
  app.post("/api/comments", requireAuth, async (req, res) => {
    try {
      const validatedData = insertUserCommentSchema.parse({
        ...req.body,
        userId: req.user?.id,
        stationId: req.user?.stationId
      });

      // Check if comment already exists
      const existingComment = await storage.getUserComment(
        validatedData.userId,
        validatedData.month,
        validatedData.year,
        validatedData.stationId
      );

      let savedComment;
      if (existingComment) {
        // Update existing comment
        savedComment = await storage.updateUserComment(
          existingComment.id,
          validatedData.comment
        );
      } else {
        // Create new comment
        savedComment = await storage.createUserComment(validatedData);
      }

      res.status(201).json(savedComment);
    } catch (error) {
      console.error("Error saving user comment:", error);
      res.status(500).json({ message: "Failed to save comment" });
    }
  });

  // Delete user comment
  app.delete("/api/comments/:id", requireAuth, async (req, res) => {
    try {
      const commentId = parseInt(req.params.id);
      
      // Verify ownership (users can only delete their own comments)  
      const userId = req.user?.id;
      if (!userId) return res.sendStatus(401);
      // For now, allow deletion if user is admin or owns the comment
      
      await storage.deleteUserComment(commentId);
      res.status(200).json({ message: "Comment deleted successfully" });
    } catch (error) {
      console.error("Error deleting comment:", error);
      res.status(500).json({ message: "Failed to delete comment" });
    }
  });

  // Get all comments for month/year (admin only)
  app.get("/api/comments/all/:month/:year", requireAdmin, async (req, res) => {
    try {
      const { month, year } = req.params;
      console.log(`Fetching comments for month: ${month}, year: ${year}`);
      
      const comments = await storage.getAllUserComments(
        parseInt(month),
        parseInt(year)
      );
      
      console.log(`Found ${comments.length} comments:`, comments);
      
      // Get user details for each comment
      const users = await storage.getAllUsers();
      const commentsWithUsers = comments.map(comment => {
        const user = users.find(u => u.id === comment.userId);
        return {
          ...comment,
          user: user ? {
            id: user.id,
            username: user.username,
            firstName: user.firstName,
            lastName: user.lastName
          } : null
        };
      });
      
      console.log(`Returning ${commentsWithUsers.length} comments with user details`);
      res.json(commentsWithUsers);
    } catch (error) {
      console.error("Error getting all comments:", error);
      res.status(500).json({ message: "Failed to get comments" });
    }
  });

  // Deadline configuratie routes
  
  // Get current deadline setting (days before month)
  app.get("/api/system/deadline-days", requireAuth, async (req, res) => {
    try {
      const userStationId = (req.user as any).stationId;
      const settingKey = `preference_deadline_days_station_${userStationId}`;
      const setting = await storage.getSystemSetting(settingKey);
      // Default to 1 day if not set
      const days = setting ? parseInt(setting) : 1;
      res.json({ days });
    } catch (error) {
      console.error("Error getting deadline setting:", error);
      res.status(500).json({ message: "Failed to get deadline setting" });
    }
  });

  // Update deadline setting (admin only)
  app.post("/api/system/deadline-days", requireAdmin, async (req, res) => {
    try {
      const { days } = req.body;
      const userStationId = (req.user as any).stationId;
      
      if (!days || days < 1 || days > 60) {
        return res.status(400).json({ message: "Dagen moet tussen 1 en 60 zijn" });
      }
      
      const settingKey = `preference_deadline_days_station_${userStationId}`;
      await storage.setSystemSetting(settingKey, days.toString());
      res.json({ days, message: "Deadline instelling bijgewerkt" });
    } catch (error) {
      console.error("Error updating deadline setting:", error);
      res.status(500).json({ message: "Failed to update deadline setting" });
    }
  });

  // WORKAROUND: Station switcher zonder JavaScript
  app.get("/station-switcher", requireAuth, async (req: any, res) => {
    try {
      const accessibleStations = await storage.getUserAccessibleStations(req.user.id);
      const currentStationName = accessibleStations.find(s => s.id === req.user.stationId)?.displayName || "Onbekend";
      
      res.send(`
<!DOCTYPE html>
<html>
<head>
  <title>Station Switcher</title>
  <meta charset="UTF-8">
  <style>
    body { font-family: Arial, sans-serif; padding: 20px; background: #f8fafc; }
    .container { max-width: 600px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
    .station-option { margin: 15px 0; padding: 15px; border: 2px solid #e5e7eb; border-radius: 6px; }
    .current-station { background: #dcfce7; border-color: #16a34a; }
    .other-station { background: #f8fafc; }
    button { background: #3b82f6; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; font-size: 14px; }
    button:hover { background: #2563eb; }
    .back-link { display: inline-block; margin-top: 20px; color: #3b82f6; text-decoration: none; padding: 10px 20px; border: 1px solid #3b82f6; border-radius: 4px; }
    .back-link:hover { background: #3b82f6; color: white; }
  </style>
</head>
<body>
  <div class="container">
    <h1>🏥 Station Switcher</h1>
    <h2>Welkom ${req.user.firstName} ${req.user.lastName} (${req.user.username})</h2>
    
    <p><strong>Huidig actieve station:</strong> ${currentStationName}</p>
    <p>Je hebt toegang tot ${accessibleStations.length} stations:</p>
    
    ${accessibleStations.map(station => `
      <div class="station-option ${station.id === req.user.stationId ? 'current-station' : 'other-station'}">
        <h3>${station.displayName}</h3>
        <p><strong>Code:</strong> ${station.code}</p>
        ${station.id === req.user.stationId 
          ? '<p><strong>✅ Momenteel actief</strong></p>' 
          : `<form method="POST" action="/switch-station" style="margin-top: 10px;">
               <input type="hidden" name="stationId" value="${station.id}">
               <button type="submit">🔄 Wissel naar ${station.displayName}</button>
             </form>`
        }
      </div>
    `).join('')}
    
    <a href="/dashboard" class="back-link">← Terug naar Dashboard</a>
    
    <details style="margin-top: 30px; padding: 15px; background: #f1f5f9; border-radius: 6px;">
      <summary style="cursor: pointer; font-weight: bold;">Debug Info</summary>
      <pre style="margin-top: 10px; font-size: 12px;">
User ID: ${req.user.id}
Username: ${req.user.username}  
Current Station ID: ${req.user.stationId}
Accessible Stations: ${JSON.stringify(accessibleStations, null, 2)}
      </pre>
    </details>
  </div>
</body>
</html>
      `);
    } catch (error) {
      console.error("Error rendering station switcher:", error);
      res.status(500).send("Error loading station switcher");
    }
  });

  // Feestdagen routes
  
  // Get all holidays for a year (optionally filtered by station)
  app.get("/api/holidays", requireAuth, async (req, res) => {
    try {
      const { year } = req.query;
      const userStationId = (req.user as any).stationId;
      
      if (!year) {
        return res.status(400).json({ message: "Year parameter is required" });
      }
      
      const holidays = await storage.getAllHolidays(parseInt(year as string), userStationId);
      res.json(holidays);
    } catch (error) {
      console.error("Error getting holidays:", error);
      res.status(500).json({ message: "Failed to get holidays" });
    }
  });
  
  // Get specific holiday
  app.get("/api/holidays/:id", requireAuth, async (req, res) => {
    try {
      const holidayId = parseInt(req.params.id);
      const holiday = await storage.getHoliday(holidayId);
      
      if (!holiday) {
        return res.status(404).json({ message: "Holiday not found" });
      }
      
      res.json(holiday);
    } catch (error) {
      console.error("Error getting holiday:", error);
      res.status(500).json({ message: "Failed to get holiday" });
    }
  });
  
  // Create new holiday (admin only)
  app.post("/api/holidays", requireAdmin, async (req, res) => {
    try {
      const userStationId = (req.user as any).stationId;
      
      console.log("=== CREATE HOLIDAY DEBUG ===");
      console.log("Raw req.body:", req.body);
      console.log("req.body.date value:", req.body.date);
      console.log("req.body.date type:", typeof req.body.date);
      console.log("new Date(req.body.date):", new Date(req.body.date));
      console.log("isNaN(new Date(req.body.date)):", isNaN(new Date(req.body.date).getTime()));
      
      // Prepare data for validation (include year BEFORE validation)
      const rawData = {
        ...req.body,
        year: new Date(req.body.date).getFullYear(), // Calculate year from date string
        stationId: req.body.stationId || userStationId,
        category: req.body.category || (req.body.stationId ? "regional" : "national"),
        isFixed: true // Default value for custom holidays
      };
      
      console.log("Raw data before validation:", rawData);
      
      // Validate using Zod schema (automatically coerces string to Date)
      const holidayData = insertHolidaySchema.parse(rawData);
      
      console.log("Final validated holidayData:", holidayData);
      
      const holiday = await storage.createHoliday(holidayData);
      res.status(201).json(holiday);
    } catch (error) {
      console.error("Error creating holiday:", error);
      res.status(500).json({ message: "Failed to create holiday" });
    }
  });
  
  // Update holiday (admin only)
  app.patch("/api/holidays/:id", requireAdmin, async (req, res) => {
    try {
      const holidayId = parseInt(req.params.id);
      const updateData = {
        ...req.body,
        updatedAt: new Date()
      };
      
      if (req.body.date) {
        updateData.date = new Date(req.body.date);
        updateData.year = new Date(req.body.date).getFullYear();
      }
      
      const holiday = await storage.updateHoliday(holidayId, updateData);
      res.json(holiday);
    } catch (error) {
      console.error("Error updating holiday:", error);
      res.status(500).json({ message: "Failed to update holiday" });
    }
  });
  
  // Delete holiday (admin only)
  app.delete("/api/holidays/:id", requireAdmin, async (req, res) => {
    try {
      const holidayId = parseInt(req.params.id);
      
      // Check if holiday exists
      const holiday = await storage.getHoliday(holidayId);
      if (!holiday) {
        return res.status(404).json({ message: "Holiday not found" });
      }
      
      await storage.deleteHoliday(holidayId);
      res.status(200).json({ message: "Holiday deleted successfully" });
    } catch (error) {
      console.error("Error deleting holiday:", error);
      res.status(500).json({ message: "Failed to delete holiday" });
    }
  });
  
  // Generate Belgian holidays for a specific year (admin only)
  app.post("/api/holidays/generate-belgian/:year", requireAdmin, async (req, res) => {
    try {
      const year = parseInt(req.params.year);
      const userStationId = (req.user as any).stationId;
      
      if (year < 2020 || year > 2050) {
        return res.status(400).json({ message: "Year must be between 2020 and 2050" });
      }
      
      const generatedHolidays = await storage.generateBelgianHolidays(year, userStationId);
      
      res.status(201).json({
        message: `Generated ${generatedHolidays.length} Belgian holidays for ${year}`,
        holidays: generatedHolidays
      });
    } catch (error) {
      console.error("Error generating Belgian holidays:", error);
      res.status(500).json({ message: "Failed to generate Belgian holidays" });
    }
  });
  
  // Check if a specific date is a holiday
  app.get("/api/holidays/check/:date", requireAuth, async (req, res) => {
    try {
      const dateParam = req.params.date;
      const userStationId = (req.user as any).stationId;
      
      const checkDate = new Date(dateParam);
      if (isNaN(checkDate.getTime())) {
        return res.status(400).json({ message: "Invalid date format" });
      }
      
      const isHolidayDay = await storage.isHoliday(checkDate, userStationId);
      const holidays = await storage.getHolidaysForDate(checkDate, userStationId);
      
      res.json({
        date: checkDate.toISOString(),
        isHoliday: isHolidayDay,
        holidays: holidays
      });
    } catch (error) {
      console.error("Error checking holiday:", error);
      res.status(500).json({ message: "Failed to check holiday" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}